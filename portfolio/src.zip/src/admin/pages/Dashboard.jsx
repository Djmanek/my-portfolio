export default function Dashboard() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Dashboard</h2>
      <p>Welcome to Admin Panel 🚀</p>
    </div>
  );
}